# Little Navmap and Little Navconnect Language Package

TODO_FOR_TRANSLATORS_TRANSLATE_THIS_FILE_TO_YOUR_LOCAL_LANGUAGE_AND_RENAME_THE_FILE_ACCORDINGLY_LIKE_LEAME.txt_OR_LIESMICH.txt.

Translation by TODO_ENTER_YOUR_EMAIL_NAME_AND_COPYRIGHT_HERE_AS_YOU_LIKE.

Based on Little Navmap version TODO_ENTER_LNM_VERSION_THIS_PACKAGE_IS_BASED_ON.

This is a language extension package for Little Navmap and Little Navconnect.
You might use this package for older or newer versions of these programs than
this package was created for. Translations might be missing
if versions do not match and the English text is used as a fall back.

A new release of Little Navmap might already contain this translation. In doubt check the
contents of the downloaded archive if it contains the translation files for this language.

## Installation

### Windows and Linux

Extract the contents of this archive so that the files in the folders `translations` and `help` go
into the corresponding program folders. Overwrite any present files.

### macOS

Open the Finder, click on the _Little Navmap_ application and select `Show Package Contents` in the
context menu. Copy the included `*.qm` translation files to `Little Navmap.app/Contents/MacOS`.
Overwrite any present files. Do the same for any optional translated help files. These go into
`Little Navmap.app/Contents/MacOS/help`.

## Contents

`XX` denotes the language code for the supported translation. E.g. `fr` for French or `pt_BR` for
Brazilian Portuguese.

### Little Navmap

#### translations:

This folder contains translations for the graphical user interface of Little Navmap. These have to
go into the `translations` folder within the Little Navmap folder.

`.../Little Navmap/translations/atools_XX.qm`

`.../Little Navmap/translations/littlenavmap_XX.qm`

#### help:

This folder is optional and contains the translated PDF manual of Little Navmap.

`.../Little Navmap/help/little-navmap-user-manual-XX.pdf`

Optionally, an empty text file can indicate the availability of a translated online manual. The
programs will fall back to the English online manual independent of translated PDF offline manual
if this file is not included.

`.../Little Navmap/help/little-navmap-user-manual-XX.online`

### Little Navconnect

Same as above.

## License

This software is licensed under GPL3 or any later version.

The source code for the applications is available at Github:

https://github.com/albar965/atools

https://github.com/albar965/littlenavmap

https://github.com/albar965/littlenavconnect

Applications are copyright 2015-2018 Alexander Barthel (albar965@mailbox.org).
